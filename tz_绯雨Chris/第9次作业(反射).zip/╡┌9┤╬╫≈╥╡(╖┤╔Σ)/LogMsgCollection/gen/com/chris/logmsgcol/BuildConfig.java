/** Automatically generated file. DO NOT MODIFY */
package com.chris.logmsgcol;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}